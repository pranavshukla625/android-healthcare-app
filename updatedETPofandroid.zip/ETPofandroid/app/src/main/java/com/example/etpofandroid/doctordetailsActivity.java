package com.example.etpofandroid;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class doctordetailsActivity extends AppCompatActivity {

    private String[][] doctor_details1 = {
            {"Doctor Name: Ajit Saste", "Hospital Address: Pimpri", "Exp: 5yrs", "Mobile No:9898989898", "608"},
            {"Doctor Name: Prasad Pawar", "Hospital Address: Nigdi", "Exp: 15yrs", "Mobile No:7898989898", "900"},
            {"Doctor Name: Swapnil Kale", "Hospital Address: Pune", "Exp: Byrs", "Mobile No:8898989898", "300"},
            {"Doctor Name: Deepak Deshmukh", "Hospital Address: Chinchwad", "Exp: byrs", "Mobile No:9898000000", "500"},
            {"Doctor Name: Ashok Panda", "Hospital Address: Katrai", "Exp: 7yrs", "Mobile No:7798989898", "800"}
    };

    private String[][] doctor_details2 = {
            {"Doctor Name: Ajit Saste", "Hospital Address: Pimpri", "Exp: 5yrs", "Mobile No:9898989898", "608"},
            {"Doctor Name: Prasad Pawar", "Hospital Address: Nigdi", "Exp: 15yrs", "Mobile No:7898989898", "900"},
            {"Doctor Name: Swapnil Kale", "Hospital Address: Pune", "Exp: Byrs", "Mobile No:8898989898", "300"},
            {"Doctor Name: Deepak Deshmukh", "Hospital Address: Chinchwad", "Exp: byrs", "Mobile No:9898000000", "500"},
            {"Doctor Name: Ashok Panda", "Hospital Address: Katrai", "Exp: 7yrs", "Mobile No:7798989898", "800"}
    };

    private String[][] doctor_details3 = {
            {"Doctor Name: Ajit Saste", "Hospital Address: Pimpri", "Exp: 5yrs", "Mobile No:9898989898", "608"},
            {"Doctor Name: Prasad Pawar", "Hospital Address: Nigdi", "Exp: 15yrs", "Mobile No:7898989898", "900"},
            {"Doctor Name: Swapnil Kale", "Hospital Address: Pune", "Exp: Byrs", "Mobile No:8898989898", "300"},
            {"Doctor Name: Deepak Deshmukh", "Hospital Address: Chinchwad", "Exp: byrs", "Mobile No:9898000000", "500"},
            {"Doctor Name: Ashok Panda", "Hospital Address: Katrai", "Exp: 7yrs", "Mobile No:7798989898", "800"}
    };

    private String[][] doctor_details4 = {
            {"Doctor Name: Ajit Saste", "Hospital Address: Pimpri", "Exp: 5yrs", "Mobile No:9898989898", "608"},
            {"Doctor Name: Prasad Pawar", "Hospital Address: Nigdi", "Exp: 15yrs", "Mobile No:7898989898", "900"},
            {"Doctor Name: Swapnil Kale", "Hospital Address: Pune", "Exp: Byrs", "Mobile No:8898989898", "300"},
            {"Doctor Name: Deepak Deshmukh", "Hospital Address: Chinchwad", "Exp: byrs", "Mobile No:9898000000", "500"},
            {"Doctor Name: Ashok Panda", "Hospital Address: Katrai", "Exp: 7yrs", "Mobile No:7798989898", "800"}
    };

    private String[][] doctor_details = {}; // Empty default array
    private HashMap<String, String> item;
    private ArrayList<HashMap<String, String>> list = new ArrayList<>();
    private SimpleAdapter sa;

    //@SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctordetails);

        // Initialize UI elements
        TextView tv = findViewById(R.id.textViewDDTitle);
        Button btn = findViewById(R.id.buttonDDBack);

        // Get the title from the Intent
        Intent it = getIntent();
        String title = it.getStringExtra("title");
        tv.setText(title);

        // Set doctor details based on the title
        if ("Physicians".equals(title)) {
            doctor_details = doctor_details1;
        } else if ("Dentist".equals(title)) {
            doctor_details = doctor_details2;
        } else if ("Cardiologist".equals(title)) {
            doctor_details = doctor_details3;
        } else if ("Allergist".equals(title)) {
            doctor_details = doctor_details4;
        }

        // Set onClickListener for the back button
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(doctordetailsActivity.this, finddoctorActivity2.class));
            }
        });

        // Populate the ListView with doctor details
        for (int i = 0; i < doctor_details.length; i++) {
            item = new HashMap<>();
            item.put("line1", doctor_details[i][0]);
            item.put("line2", doctor_details[i][1]);
            item.put("line3", doctor_details[i][2]);
            item.put("line4", doctor_details[i][3]);
            item.put("line5", "Cons Fees : " + doctor_details[i][4] + "/-");
            list.add(item);
        }

        // Set up SimpleAdapter to display the doctor details in the ListView
        sa = new SimpleAdapter(this, list,
                R.layout.multi_lines, // Make sure this layout exists and has the correct IDs
                new String[]{"line1", "line2", "line3", "line4", "line5"},
                new int[]{R.id.line_a, R.id.line_b, R.id.line_c, R.id.line_d, R.id.line_e}
        );

        ListView lst = findViewById(R.id.listViewDD);
        lst.setAdapter(sa);

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent it = new Intent(doctordetailsActivity.this,BookApointmentActivity.class);
                it.putExtra("text1",title);
                it.putExtra("text2",doctor_details[i][0]);
                it.putExtra("text2",doctor_details[i][1]);
                it.putExtra("text2",doctor_details[i][3]);
                it.putExtra("text2",doctor_details[i][4]);
                startActivity(it);
            }
        });
    }
}
