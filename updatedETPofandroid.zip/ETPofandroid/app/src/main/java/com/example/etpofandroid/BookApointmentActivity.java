package com.example.etpofandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BookApointmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_apointment);


        EditText ed1 = findViewById(R.id.editTextAppFullName);
        EditText ed2 = findViewById(R.id.editTextAppAddress);
        EditText ed3 = findViewById(R.id.editTextAppContactNumber);
        EditText ed4 = findViewById(R.id.editTextAppFees);


        ed1.setFocusable(false);
        ed2.setFocusable(false);
        ed3.setFocusable(false);
        ed4.setFocusable(false);


        Intent it = getIntent();


        String title = it.getStringExtra("text1");
        String fullname = it.getStringExtra("text2");
        String address = it.getStringExtra("text3");
        String contact = it.getStringExtra("text4");
        String fees = it.getStringExtra("text5");

        ed1.setText(fullname);
        ed2.setText(address);
        ed3.setText(contact);
        ed4.setText("Cons Fees: " + fees + "/-");
    }
}
